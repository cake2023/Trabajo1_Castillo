<?php ini_set("display_errors","1");?>
<?php
    require "../entities/vehiculo.php";
    require "../entities/auto_nuevo.php";
    require "../entities/auto_clasico.php";
    require "../entities/bondi.php";
    require "../entities/radio.php";
    
    echo "<h1>Test Vehiculos</h1>";
    echo "<h2>---Test Auto Nuevo---</h2>"; 
    $auto_nuevo1=new AutoNuevo("Gris", "Renault","Oroch", new Radio("Libercam", 25));   //Objeto creado de Auto Nuevo con radio.
    echo $auto_nuevo1;
    $auto_nuevo1->cambiarRadio("Hallbar",60);   //Se cambia la radio de objeto $auto_nuevo1 por otra nueva.
    echo $auto_nuevo1;
    $auto_nuevo1->agregarRadio("Boss Audio System", 45);     //Se agrega radio a objeto $auto_nuevo1 .
    echo $auto_nuevo1;
    echo "<h3>---End Test Auto Nuevo---</h3>";
   
    echo "<h2>---Test Auto Clásico---</h2>"; 
    $auto_clasico1=new AutoClasico("Rojo","Porsche","Coupe",500000);   //Objeto creado de Auto Clásico con precio y sin radio.
    echo $auto_clasico1;
    $auto_clasico1->agregarRadio("Smart Tech", 25);     //Se agrega radio a objeto AutoClasico.
    echo $auto_clasico1;
    $auto_clasico1->cambiarRadio("JVC",50);     //Se cambia la radio de objeto AutoClasico por otra nueva.
    echo $auto_clasico1;
    echo "<h3>---End Test Auto Clásico---</h3>"; 
     
    echo "<h2>---Test Auto Bondi---</h2>"; 
    $bondi1=new Bondi("Blanco","Mercedes Benz","Minibus");      //Objeto creado de Bondi o Colectivo sin radio.
    echo $bondi1;
    $bondi1->agregarRadio("Boss Audio System", 50);     //Se agrega radio a objeto Bondi.
    echo $bondi1.$bondi1->getRadio;
    $bondi1->cambiarRadio("X-View", potencia: 45);      //Se cambia la radio de objeto Bondi por otra nueva.
    echo $bondi1;
    echo "<h3>---End Test Auto Bondi---</h3>";

 


