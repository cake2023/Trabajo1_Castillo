<?php ini_set("display_errors","1");?>
<?php
    //localhost/Trabajo1_Castillo_Arelys/php/test/test_php.php
    
    echo "Versión PHP: ".phpversion()."<br>";
    echo phpinfo().'<br>';

?>