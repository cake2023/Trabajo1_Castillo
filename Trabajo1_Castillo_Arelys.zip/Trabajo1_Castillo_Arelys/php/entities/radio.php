<?php
class Radio{
    private $marca_radio;
    private $potencia;
    
    public function __construct(string $marca_radio, int $potencia){
        $this->marca_radio=$marca_radio;
        $this->potencia=$potencia;
    }
    
    public function __tostring(){
        return "Radio: (marca:  ".$this->marca_radio.", potencia:  ". $this->potencia."W)";
    }

    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }
    }
    
    public function __set($property, $value){
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>