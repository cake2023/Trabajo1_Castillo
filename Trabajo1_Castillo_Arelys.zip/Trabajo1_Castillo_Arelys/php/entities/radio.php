<?php
class Radio{
    private $marca;
    private $potencia;
    
    public function __construct(string $marca, int $potencia){
        $this->marca=$marca;
        $this->potencia=$potencia;
    }
    
    public function __tostring(){
        return "Radio: (marca:  ".$this->marca.", potencia:  ". $this->potencia."W)";
    }

    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }
    }
    
    public function __set($property, $value){
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>