<?php
class AutoClasico extends Vehiculo{
   public function __construct(string $color, string $marca, string $modelo,public float $precio){
      parent::__construct($color,$marca,$modelo);
      $this->precio=$precio;
      $this->agregarRadio;
      $this->cambiarRadio; 
   }

   public function __tostring(){
      return " Precio: $".number_format($this->precio,2,',','.').
             ". ".parent::__tostring();
   }
}
?>