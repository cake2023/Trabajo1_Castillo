<?php
abstract class Vehiculo{
    private $color;
    private $marca;
    private $modelo;
    private $precio;
    private $radio;
    
    public function __construct(string $color, string $marca, string $modelo){
        $this->color=$color;
        $this->marca=$marca;
        $this->modelo=$modelo; 
    }
    
    public function cambiarRadio(string $marca, int $potencia) :void{
        $this->radio=new Radio($marca,$potencia);
    }

    public function agregarRadio(string $marca, int $potencia) :void{
        $this->radio=new Radio($marca,$potencia);
    }
    
    public function __tostring(){
        return "Color: ".$this->color.", Marca: ".$this->marca.", Modelo: ".
               $this->modelo.". ".$this->radio."<br>";
    }

    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }
    }

    public function __set($property, $value){
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>