<?php
class Bondi extends Vehiculo{
    public function __construct(string $color, string $marca, string $modelo){
        parent::__construct($color,$marca,$modelo);
        $this->agregarRadio;
        $this->cambiarRadio;    
    }
}                               
?>