<?php
class Bondi extends Vehiculo{
    public function __construct(string $color, string $marca, string $modelo){
        $this->color=$color;
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->agregarRadio;
        $this->cambiarRadio;    
    }
}                               
?>