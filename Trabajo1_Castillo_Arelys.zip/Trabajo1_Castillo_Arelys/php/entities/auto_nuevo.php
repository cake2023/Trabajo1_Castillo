<?php
class AutoNuevo extends Vehiculo{
      public function __construct(string $color,string $marca,string $modelo,string $marca_radio, int $potencia){ 
        $this->color=$color;
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->radio=new Radio($marca_radio,$potencia);
        $this->cambiarRadio; 
        $this->agregarRadio;
    } 
}                          
?>