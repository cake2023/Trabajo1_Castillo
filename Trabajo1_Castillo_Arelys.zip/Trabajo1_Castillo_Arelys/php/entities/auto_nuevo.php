<?php
class AutoNuevo extends Vehiculo{
    public function __construct(string $color,string $marca,string $modelo,public Radio $radio){
        parent::__construct($color,$marca,$modelo);
        $this->radio=$radio;
        $this->cambiarRadio; 
        $this->agregarRadio;
    }
}                          
?>